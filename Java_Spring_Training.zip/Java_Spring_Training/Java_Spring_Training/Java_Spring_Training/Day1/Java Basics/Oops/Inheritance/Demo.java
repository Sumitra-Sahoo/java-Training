public class Demo {
    public static void main(String[] args){
        Test test=new Test();
        NormalTest normaltest=new NormalTest();
        ExecAdmin execadmin=new ExecAdmin();
        AdminUser adminuser=new AdminUser();
        SuperAdmin superadmin=new SuperAdmin();
    }
}
